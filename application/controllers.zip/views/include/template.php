<?php
$this->load->view("include/header");
$this->load->view($mainContent);

$this->load->view("include/footer");
?>